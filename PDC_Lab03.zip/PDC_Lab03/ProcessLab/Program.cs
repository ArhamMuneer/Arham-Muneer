﻿using System;
using System.Diagnostics;
using System.Net;

class Program
{
    static void Main(string[] args)
    {
        if (args.Length > 0 && args[0] == "--child")
        {
            RunAsChild();
        }
        else
        {
            RunAsParent();
        }
    }
    static void RunAsChild()
    {
        Console.WriteLine($"[Child] PID = {Environment.ProcessId}");
        int counter = 100;
        counter += 50;
        Console.WriteLine($"[Child] final counter = {counter}");
    }

    static void RunAsParent()
    {
        Console.WriteLine($"[Parent] PID = {Environment.ProcessId}");
        int counter = 100;
        counter += 1;

        string? executeablePath = Environment.ProcessPath;

        if (executeablePath == null)
        {
            Console.WriteLine("Executeable path not found");
            return;
        }

        ProcessStartInfo startInfo = new ProcessStartInfo
        {
            FileName = executeablePath,
            UseShellExecute = false
        };

        startInfo.ArgumentList.Add("--child");

        using (Process? child = Process.Start(startInfo))
        {
            if (child == null)
            {
                Console.WriteLine("Failed to start child process");
                return;
            }
            child.WaitForExit();
        }
        Console.WriteLine($"[Parent] Final counter = {counter}");

        Console.WriteLine("Parent and child counters were modified independently");
    }
}