﻿using System;
using System.Threading;

class Program
{
    static void Worker()
    {
        Thread.Sleep(200);
    }

    static void Main()
    {
        Thread t = new Thread(Worker);

        Console.WriteLine(
            $"After creation: {t.ThreadState}"
        );

        t.Start();

        // Conceptual state: Runnable/Ready or Running
        Console.WriteLine(
            $"Immediately after Start(): {t.ThreadState}"
        );

        // Allow the worker to enter its sleeping state.
        Thread.Sleep(50);

        // Conceptual state: Blocked/Waiting
        Console.WriteLine(
            $"While worker is sleeping: {t.ThreadState}"
        );

        // Wait for the worker thread to finish.
        t.Join();
        
        Console.WriteLine(
            $"After Join() completes: {t.ThreadState}"
        );
    }
}