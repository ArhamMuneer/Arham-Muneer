﻿using System;
using System.Threading;

class Program
{
    // Large array containing 10 million numbers
    static long[] data = new long[10_000_000];

    // Stores the sum calculated by each worker
    static long[] partialSums;

    // Number of worker threads
    static int numWorkers;

    // Worker method
    static void SumSlice(object? arg)
    {
        int idx = (int)arg!;

        // Calculate size of each slice
        int sliceSize = data.Length / numWorkers;

        // Calculate starting position
        int start = idx * sliceSize;

        // Calculate ending position
        int end = (idx == numWorkers - 1)
            ? data.Length
            : start + sliceSize;

        long sum = 0;

        // Add all values in this worker's slice
        for (int i = start; i < end; i++)
        {
            sum += data[i];
        }

        // Store result in this worker's own slot
        partialSums[idx] = sum;
    }

    static void Main()
    {
        // Fill the array with numbers 1 to 10,000,000
        for (int i = 0; i < data.Length; i++)
        {
            data[i] = i + 1;
        }

        // Use the number of logical processors available
        numWorkers = Environment.ProcessorCount;

        // Create one slot for each worker
        partialSums = new long[numWorkers];

        // Create thread array
        Thread[] threads = new Thread[numWorkers];

        // Create and start worker threads
        for (int i = 0; i < numWorkers; i++)
        {
            int idx = i;

            threads[i] = new Thread(() => SumSlice(idx));
            threads[i].Start();
        }

        // Wait for every thread to finish
        for (int i = 0; i < numWorkers; i++)
        {
            threads[i].Join();
        }

        // Combine partial sums
        long threadedTotal = 0;

        foreach (long partial in partialSums)
        {
            threadedTotal += partial;
        }

        // Calculate total using one sequential loop
        long sequentialTotal = 0;

        foreach (long value in data)
        {
            sequentialTotal += value;
        }

        // Display results
        Console.WriteLine($"Array Size: {data.Length}");
        Console.WriteLine($"Worker Threads: {numWorkers}");
        Console.WriteLine($"Threaded total: {threadedTotal}");
        Console.WriteLine($"Sequential total: {sequentialTotal}");
        Console.WriteLine($"Match: {threadedTotal == sequentialTotal}");
    }
}