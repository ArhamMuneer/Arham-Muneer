﻿using System;
using System.Diagnostics;
using System.Threading;

class Program
{
    const int Iterations = 50;

    static void Main(string[] args)
    {
        // Child process performs trivial work and exits
        if (args.Length > 0 && args[0] == "--child")
        {
            return;
        }

        // Run the comparison twice
        for (int run = 1; run <= 2; run++)
        {
            Console.WriteLine($"\nRun {run}");

            string? executablePath = Environment.ProcessPath;

            if (executablePath == null)
            {
                Console.WriteLine("Executable path not found.");
                return;
            }

            // Measure process creation overhead
            Stopwatch processStopwatch = Stopwatch.StartNew();

            for (int i = 0; i < Iterations; i++)
            {
                ProcessStartInfo info = new ProcessStartInfo
                {
                    FileName = executablePath,
                    UseShellExecute = false
                };

                info.ArgumentList.Add("--child");

                using (Process? child = Process.Start(info))
                {
                    if (child == null)
                    {
                        throw new Exception("Failed to start process.");
                    }

                    child.WaitForExit();
                }
            }

            processStopwatch.Stop();

            // Measure thread creation overhead
            Stopwatch threadStopwatch = Stopwatch.StartNew();

            for (int i = 0; i < Iterations; i++)
            {
                Thread t = new Thread(() => { });

                t.Start();
                t.Join();
            }

            threadStopwatch.Stop();

            // Calculate
            double avgProcessMs =
                processStopwatch.Elapsed.TotalMilliseconds / Iterations;

            double avgThreadMs =
                threadStopwatch.Elapsed.TotalMilliseconds / Iterations;

            double ratio = avgProcessMs / avgThreadMs;

            // Display
            Console.WriteLine(
                $"Average process creation: {avgProcessMs:F3} ms"
            );

            Console.WriteLine(
                $"Average thread creation: {avgThreadMs:F3} ms"
            );

            Console.WriteLine(
                $"Process / Thread ratio: {ratio:F1}x"
            );
        }
    }
}